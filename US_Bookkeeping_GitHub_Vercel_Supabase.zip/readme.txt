NETLIFY DEPLOY INSTRUCTIONS
1. Extract this ZIP file first.
2. Open https://app.netlify.com/drop in Chrome.
3. Sign in to Netlify.
4. Drag the extracted folder (US_Bookkeeping_StudyBook_500_Netlify) onto the Drop page.
5. Wait for deployment, then open the generated *.netlify.app link.
IMPORTANT: Upload the extracted FOLDER, not the ZIP file. Keep index.html at the top level.
