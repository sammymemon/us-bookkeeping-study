# US Bookkeeping Study Book

Static PWA containing 500 US bookkeeping and accounting interview questions. The original study content and reader interface are retained. Local progress remains available in the browser; optional Supabase authentication and cloud sync syncs read/bookmarked question status across devices.

## Deploy on Vercel

1. Import this GitHub repository into Vercel.
2. Framework preset: **Other**. Build command: leave blank. Output directory: `.`.
3. Deploy the project.

## Enable Supabase cloud sync

1. Create a Supabase project.
2. In Supabase Dashboard -> SQL Editor, run `supabase-schema.sql`.
3. Copy the Project URL and the publishable key (or legacy anon key) from Project Settings -> API.
4. Put them in `supabase-config.js` as `url` and `anonKey`. Do not use the `service_role` or secret key in browser code.
5. In Supabase Authentication -> URL Configuration, add your Vercel deployment URL to Site URL and Redirect URLs.
6. Redeploy on Vercel. Open the study book on laptop and mobile and sign in using the same account.

The app uses Supabase Auth and Row Level Security. Each authenticated user can read/write only their own progress rows.
