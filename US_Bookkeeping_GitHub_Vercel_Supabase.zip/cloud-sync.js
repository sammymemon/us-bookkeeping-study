(() => {
  const statusEl = document.getElementById('cloudStatus');
  const emailEl = document.getElementById('authEmail');
  const passwordEl = document.getElementById('authPassword');
  const signInBtn = document.getElementById('signInBtn');
  const signUpBtn = document.getElementById('signUpBtn');
  const signOutBtn = document.getElementById('signOutBtn');
  const config = window.SUPABASE_CONFIG || {};
  let client = null;
  let currentUser = null;
  let syncTimer = null;
  let syncBusy = false;
  let syncAgain = false;
  let cloudRows = new Set();

  function status(message) { if (statusEl) statusEl.textContent = message; }
  function setAuthControls(signedIn) {
    if (signInBtn) signInBtn.hidden = signedIn;
    if (signUpBtn) signUpBtn.hidden = signedIn;
    if (signOutBtn) signOutBtn.hidden = !signedIn;
    if (emailEl) emailEl.disabled = signedIn;
    if (passwordEl) passwordEl.disabled = signedIn;
  }
  function isConfigured() {
    return config.url && config.anonKey &&
      !String(config.url).includes('YOUR_SUPABASE') &&
      !String(config.anonKey).includes('YOUR_SUPABASE');
  }
  function getQuestionIds() {
    const ids = new Set([
      ...Object.keys(window.state?.read || {}),
      ...Object.keys(window.state?.starred || {}),
      ...cloudRows
    ]);
    return [...ids].filter(id => /^\d+$/.test(id));
  }
  async function pushProgress() {
    if (!client || !currentUser) return;
    const rows = getQuestionIds().map(id => ({
      user_id: currentUser.id,
      question_id: String(id),
      is_read: !!window.state.read[id],
      is_bookmarked: !!window.state.starred[id],
      updated_at: new Date().toISOString()
    }));
    if (!rows.length) return;
    const { error } = await client.from('study_progress').upsert(rows, { onConflict: 'user_id,question_id' });
    if (error) throw error;
    rows.forEach(row => cloudRows.add(row.question_id));
  }
  async function loadProgress() {
    const { data, error } = await client.from('study_progress')
      .select('question_id,is_read,is_bookmarked')
      .eq('user_id', currentUser.id);
    if (error) throw error;
    const remoteIds = new Set();
    (data || []).forEach(row => {
      const id = String(row.question_id);
      remoteIds.add(id);
      cloudRows.add(id);
      // Cloud values win for records already stored there. Local-only records are retained.
      window.state.read[id] = !!row.is_read;
      window.state.starred[id] = !!row.is_bookmarked;
    });
    try { localStorage.setItem('usBookkeepingStudyProgress_v1', JSON.stringify(window.state)); } catch (_) {}
    if (typeof window.render === 'function') window.render();
    if (!remoteIds.size) {
      await pushProgress();
      status('Signed in. Your existing progress has been uploaded to the cloud.');
    } else {
      await pushProgress();
      status('Cloud sync is on. Your reading progress is synced on this device.');
    }
  }
  async function runSync() {
    if (!currentUser || !client) return;
    if (syncBusy) { syncAgain = true; return; }
    syncBusy = true;
    try {
      await pushProgress();
      status('✓ Progress synced to your account.');
    } catch (error) {
      console.error('Cloud progress sync failed:', error);
      status('Sync error: ' + (error.message || 'Check your Supabase table and Row Level Security policies.'));
    } finally {
      syncBusy = false;
      if (syncAgain) { syncAgain = false; runSync(); }
    }
  }
  window.queueCloudProgressSync = function () {
    if (!currentUser) return;
    clearTimeout(syncTimer);
    syncTimer = setTimeout(runSync, 700);
  };
  window.cloudSignIn = async function () {
    if (!client) return status('Supabase is not configured yet. Add the project URL and publishable key to supabase-config.js.');
    const email = emailEl.value.trim(), password = passwordEl.value;
    if (!email || !password) return status('Enter your email and password.');
    status('Signing in…');
    const { error } = await client.auth.signInWithPassword({ email, password });
    if (error) status(error.message);
  };
  window.cloudSignUp = async function () {
    if (!client) return status('Supabase is not configured yet. Add the project URL and publishable key to supabase-config.js.');
    const email = emailEl.value.trim(), password = passwordEl.value;
    if (!email || password.length < 6) return status('Enter an email and a password with at least 6 characters.');
    status('Creating your account…');
    const { error } = await client.auth.signUp({ email, password });
    if (error) status(error.message);
    else status('Account request sent. If email confirmation is enabled, confirm the email, then sign in.');
  };
  window.cloudSignOut = async function () {
    if (!client) return;
    const { error } = await client.auth.signOut();
    if (error) status(error.message);
  };
  async function handleSession(session) {
    currentUser = session?.user || null;
    setAuthControls(!!currentUser);
    if (!currentUser) {
      status(isConfigured() ? 'Signed out. Sign in to sync progress across devices.' : 'Add Supabase project details to enable cloud sync.');
      return;
    }
    status('Loading your cloud progress…');
    try {
      await loadProgress();
      if (emailEl) emailEl.value = currentUser.email || '';
    } catch (error) {
      console.error('Could not load cloud progress:', error);
      status('Could not load progress: ' + (error.message || 'Check the Supabase SQL and RLS policies.'));
    }
  }
  async function init() {
    if (!isConfigured() || !window.supabase?.createClient) {
      setAuthControls(false);
      status('Cloud sync is prepared but not activated. Add your Supabase URL and publishable key in supabase-config.js.');
      return;
    }
    client = window.supabase.createClient(config.url, config.anonKey);
    const { data: { session } } = await client.auth.getSession();
    await handleSession(session);
    client.auth.onAuthStateChange((_event, sessionNow) => {
      // Defer work out of the auth callback to avoid holding its internal lock.
      setTimeout(() => handleSession(sessionNow), 0);
    });
  }
  window.addEventListener('load', init);
})();
