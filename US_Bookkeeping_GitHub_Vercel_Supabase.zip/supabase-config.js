// Add your Supabase project URL and publishable (anon) key here.
// Never put a Supabase service_role/secret key in this browser file.
window.SUPABASE_CONFIG = {
  url: 'YOUR_SUPABASE_PROJECT_URL',
  anonKey: 'YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY'
};
