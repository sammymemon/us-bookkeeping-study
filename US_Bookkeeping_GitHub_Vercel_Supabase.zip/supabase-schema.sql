-- Run this once in Supabase Dashboard -> SQL Editor.
create table if not exists public.study_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  question_id text not null,
  is_read boolean not null default false,
  is_bookmarked boolean not null default false,
  updated_at timestamptz not null default now(),
  primary key (user_id, question_id)
);

alter table public.study_progress enable row level security;

drop policy if exists "Users can read own progress" on public.study_progress;
create policy "Users can read own progress"
on public.study_progress for select to authenticated
using (auth.uid() = user_id);

drop policy if exists "Users can add own progress" on public.study_progress;
create policy "Users can add own progress"
on public.study_progress for insert to authenticated
with check (auth.uid() = user_id);

drop policy if exists "Users can update own progress" on public.study_progress;
create policy "Users can update own progress"
on public.study_progress for update to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "Users can delete own progress" on public.study_progress;
create policy "Users can delete own progress"
on public.study_progress for delete to authenticated
using (auth.uid() = user_id);
